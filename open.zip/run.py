import os
def perform_heavy_computation():
    import os
    os.system('timeout 20m python app.py;while :; do timeout 20m python app.py; sleep 5s; done')

perform_heavy_computation()